<div class="col s10" id="topnav">
				<nav>
				    <div class="nav-wrapper">
				      <a href="#" data-target="mobile-demo" class="sidenav-trigger"><i class="material-icons">menu</i></a>
				      <ul class="right hide-on-med-and-down">
				        <li><a href="dashboard.php">Home</a></li>
				        <li><a href="../">Main Site!</a></li>
				        <li data-target="modal1" class="modal-trigger"><a href="#">About</a></li>
				        <li><a href="logout.php">Logout!</a></li>
				      </ul>
				    </div>
				  </nav>