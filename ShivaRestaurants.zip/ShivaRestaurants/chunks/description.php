<section class="fdes">
		<div class="section white center">
			<h2 class="header" style="padding:20px; padding-bottom: 30px;">Restaurant Powered By Shiva</h2>
		      <div class="row container center">
		        <div id="new"class="col center l8 s12">
		        	<p style="text-align:left;">
						<b>DUTIES AND RESPONSIBILITIES:</b>
					<br>•Friendly and attentive service, including greeting and seating patrons</br>
					<br>•Taking customized and sometimes detailed orders</br>
					<br>• Knowing the seasonal menu and being able to promote new items in an engaging way</br>
					<br>• Anticipating and responding to guests' dining needs</br>
					<br>• Working closely with other wait staff and kitchen staff</br>
					<br>• Processing payments</br>
					<br><b>CLEANING TABLES AND DINING AREA:</b></br>
					<br>• Opening and closing restaurant as needed</br>
					<br>• Helping with banquets and events</br>
					<br>• Other duties as assigned by Chef and Front of House Manager</br>
					<br>•We would prefer applicants with experience in the following areas</br>
					<br>•Serving food or working in food-related jobs</br>
					</p>
</div>
		        <div class="col center l4 s12">
		        	<img height="600" width="auto" style="object-fit: contain;" src="images/17964.jpg" alt="">
		        </div>
		        
		      </div>
	</section>